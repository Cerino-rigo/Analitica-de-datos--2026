import streamlit as st
from pathlib import Path
from utils.data import load_sources, filtered_sales, build_risk_table, inventory_by_brand
from utils.styles import page_header
from utils.charts import sales_trend, risk_scatter, top_risk_bar, inventory_treemap

PATH_VENTAS = Path(__file__).resolve().parents[1] / "data" / "Datos_CLV_2026_Tec_v2.xlsx"
PATH_COMPLEMENTARIOS = Path(__file__).resolve().parents[1] / "data" / "Datos_Complementarios_CLV.xlsx"
ventas, inventario, _ = load_sources(PATH_VENTAS, PATH_COMPLEMENTARIOS)
ventas_f = filtered_sales(ventas)
riesgo = build_risk_table(ventas_f, inventario)

page_header("Resumen ejecutivo", "Ventas recientes, existencias al corte y una priorización exploratoria para conversación con compras.")

if ventas_f.empty:
    st.warning("Selecciona un rango de fechas válido en la barra lateral.")
    st.stop()

criticos = int((riesgo["nivel_riesgo"] == "Crítico").sum())
match_pct = riesgo["match_inventario"].mean() * 100
c1, c2, c3, c4 = st.columns(4)
c1.metric("Venta neta filtrada", f"${ventas_f['total_neto'].sum():,.0f}")
c2.metric("Unidades vendidas", f"{ventas_f['total_unidades'].sum():,.0f}")
c3.metric("SKUs con ventas", f"{riesgo['articulo_key'].nunique():,}")
c4.metric("SKUs críticos", f"{criticos:,}", help="Cobertura exploratoria menor a 15 días y match con inventario.")

st.markdown("<div class='note'>La cobertura usa ventas recientes como proxy de demanda y una fotografía de stock. Es una alerta exploratoria: no sustituye lead time, pedidos abiertos, stock de seguridad ni un forecast.</div>", unsafe_allow_html=True)

left, right = st.columns((1, 1.35))
with left:
    st.plotly_chart(sales_trend(ventas_f), use_container_width=True)
with right:
    fig = risk_scatter(riesgo)
    if fig:
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No hay SKUs con correspondencia en inventario para mostrar la matriz.")

left, right = st.columns((1.2, 1))
with left:
    st.plotly_chart(top_risk_bar(riesgo), use_container_width=True)
with right:
    inv_marca = inventory_by_brand(inventario)
    st.plotly_chart(inventory_treemap(inv_marca), use_container_width=True)
    

st.subheader("Tabla de seguimiento")
mostrar = ["articulo_key", "nombre_articulo", "marca", "unidades_vendidas", "venta_neta", "existencias", "cobertura_dias", "nivel_riesgo", "match_inventario"]
tabla = riesgo[mostrar].sort_values(["nivel_riesgo", "venta_neta"], ascending=[True, False])
st.dataframe(tabla, use_container_width=True, hide_index=True)
st.download_button("Descargar tabla de seguimiento", tabla.to_csv(index=False, encoding="utf-8-sig"), "tabla_riesgo_abastecimiento.csv", "text/csv")
