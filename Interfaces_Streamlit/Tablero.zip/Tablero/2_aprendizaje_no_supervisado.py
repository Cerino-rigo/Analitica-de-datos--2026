import streamlit as st
from pathlib import Path
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from utils.data import load_sources, filtered_sales, build_risk_table
from utils.styles import page_header

PATH_VENTAS = Path(__file__).resolve().parents[1] / "data" / "Datos_CLV_2026_Tec_v2.xlsx"
PATH_COMPLEMENTARIOS = Path(__file__).resolve().parents[1] / "data" / "Datos_Complementarios_CLV.xlsx"
ventas, inventario, _ = load_sources(PATH_VENTAS, PATH_COMPLEMENTARIOS)
riesgo = build_risk_table(filtered_sales(ventas), inventario)

page_header("Aprendizaje no supervisado", "Segmentación exploratoria de SKU por comportamiento comercial y disponibilidad observada.")
st.markdown("Esta página es un **cascarón funcional** para integrar el trabajo de aprendizaje no supervisado. K-Means agrupa por similitud; no predice demanda ni valida una decisión de compra.")

if riesgo.empty:
    st.warning("No hay datos para el periodo seleccionado.")
    st.stop()

with st.expander("¿Qué variables entran al clustering?"):
    st.write("Demanda diaria, venta neta, frecuencia de folios y cobertura estimada. Se estandarizan porque tienen escalas distintas.")

k = st.slider("Número de clusters (k)", 2, 6, 3)
base = riesgo[riesgo["match_inventario"]].copy()
features = ["demanda_diaria", "venta_neta", "folios", "cobertura_dias"]
base = base.replace([np.inf, -np.inf], np.nan).dropna(subset=features).copy()

if len(base) < k:
    st.warning("No hay suficientes SKU comparables para el número de clusters seleccionado.")
    st.stop()

X = StandardScaler().fit_transform(base[features])
model = KMeans(n_clusters=k, random_state=42, n_init=10)
base["cluster"] = model.fit_predict(X).astype(str)

c1, c2, c3 = st.columns(3)
c1.metric("SKUs agrupados", len(base))
c2.metric("Clusters", k)
c3.metric("Cobertura mediana", f"{base['cobertura_dias'].median():.1f} días")

fig = px.scatter(
    base, x="demanda_diaria", y="cobertura_dias", color="cluster", size="venta_neta", size_max=45,
    hover_name="nombre_articulo",
    hover_data={"marca": True, "folios": True, "existencias": True, "venta_neta": ":,.2f"},
    title="Clusters de SKU: demanda diaria vs cobertura estimada", template="plotly_white",
    labels={"demanda_diaria": "Demanda diaria", "cobertura_dias": "Cobertura (días)"},
)
st.plotly_chart(fig, use_container_width=True)

perfil = base.groupby("cluster", as_index=False).agg(
    skus=("articulo_key", "nunique"), demanda_mediana=("demanda_diaria", "median"),
    cobertura_mediana=("cobertura_dias", "median"), venta_neta_total=("venta_neta", "sum")
)
st.subheader("Perfil de clusters")
st.dataframe(perfil, use_container_width=True, hide_index=True)


