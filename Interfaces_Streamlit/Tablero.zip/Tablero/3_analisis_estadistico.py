import streamlit as st
from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from utils.data import load_sources, filtered_sales, build_risk_table
from utils.styles import page_header
from utils.charts import coverage_histogram, coverage_boxplot

PATH_VENTAS = Path(__file__).resolve().parents[1] / "data" / "Datos_CLV_2026_Tec_v2.xlsx"
PATH_COMPLEMENTARIOS = Path(__file__).resolve().parents[1] / "data" / "Datos_Complementarios_CLV.xlsx"
ventas, inventario, _ = load_sources(PATH_VENTAS, PATH_COMPLEMENTARIOS)
riesgo = build_risk_table(filtered_sales(ventas), inventario)

page_header("Análisis estadístico", "Distribuciones, comparaciones por grupo y umbrales didácticos con Seaborn.")
st.markdown("Esta página retoma únicamente las herramientas vistas: `histplot`, `boxplot`, `barplot` y tablas de resumen. Otros profesores pueden ampliar esta sección con inferencia, pronósticos o modelos.")

if riesgo.empty:
    st.warning("No hay datos para el periodo seleccionado.")
    st.stop()

c1, c2 = st.columns(2)
with c1:
    st.pyplot(coverage_histogram(riesgo, cap=180), clear_figure=True)
with c2:
    st.pyplot(coverage_boxplot(riesgo, top_n=8, cap=180), clear_figure=True)

st.subheader("Matriz porcentual de nivel de riesgo por marca")
matriz = pd.crosstab(riesgo["marca"], riesgo["nivel_riesgo"], normalize="index").mul(100)
top = riesgo.groupby("marca")["venta_neta"].sum().nlargest(12).index
matriz = matriz.reindex(top).fillna(0)
fig, ax = plt.subplots(figsize=(10, 6))
sns.heatmap(matriz, annot=True, fmt=".1f", cmap="YlOrRd", linewidths=.4, ax=ax)
ax.set(title="Composición porcentual por marca", xlabel="Nivel de riesgo", ylabel="Marca")
st.pyplot(fig, clear_figure=True)

st.subheader("Resumen descriptivo por nivel")
resumen = riesgo.groupby("nivel_riesgo", observed=False).agg(
    skus=("articulo_key", "nunique"),
    venta_neta_mediana=("venta_neta", "median"),
    cobertura_mediana=("cobertura_dias", "median"),
    existencias_mediana=("existencias", "median"),
).reset_index()
st.dataframe(resumen, use_container_width=True, hide_index=True)

with st.expander("Extensión para las últimas páginas del proyecto"):
    st.markdown("""
    - **Pronóstico / ML supervisado:** reemplazar demanda histórica por pronóstico y mostrar error del model, etc.
    - **Despliegue final:** reutilizar `utils/data.py`, colocar filtros globales en el sidebar y agregar páginas con `st.Page`.
    """)
