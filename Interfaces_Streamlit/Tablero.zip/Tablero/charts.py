import numpy as np
import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
import seaborn as sns

def sales_trend(sales):
    serie = sales.groupby("periodo", as_index=False).agg(
        unidades=("total_unidades", "sum"), venta_neta=("total_neto", "sum")
    )
    fig = px.line(
        serie, x="periodo", y="venta_neta", markers=True,
        title="Evolución de venta neta en el periodo seleccionado",
        labels={"periodo": "Mes", "venta_neta": "Venta neta"}, template="plotly_white",
    )
    fig.update_layout(hovermode="x unified")
    fig.update_xaxes(rangeslider_visible=True)
    return fig

def risk_scatter(riesgo):
    data = riesgo[riesgo["match_inventario"]].copy()
    if data.empty:
        return None
    fig = px.scatter(
        data, x="demanda_diaria", y="existencias", color="nivel_riesgo",
        size="venta_neta", size_max=45, hover_name="nombre_articulo",
        hover_data={"articulo_key": True, "marca": True, "cobertura_dias": ":.1f",
                    "venta_neta": ":,.2f", "folios": True, "clientes": True},
        title="Matriz exploratoria: demanda diaria vs existencias",
        labels={"demanda_diaria": "Demanda diaria estimada", "existencias": "Existencias al corte"},
        color_discrete_map={"Crítico": "#C62828", "Vigilar": "#F9A825", "Saludable": "#2E7D32"},
        template="plotly_white",
    )
    return fig

def top_risk_bar(riesgo, n=15):
    data = (riesgo[riesgo["nivel_riesgo"].isin(["Crítico", "Vigilar"])]
            .sort_values("venta_neta", ascending=False).head(n).sort_values("venta_neta"))
    fig = px.bar(
        data, x="venta_neta", y="nombre_articulo", color="nivel_riesgo", orientation="h",
        hover_data={"marca": True, "existencias": True, "cobertura_dias": ":.1f", "demanda_diaria": ":.2f"},
        title=f"Top {n}: SKU a revisar por cobertura y venta neta",
        labels={"venta_neta": "Venta neta", "nombre_articulo": "Producto"},
        color_discrete_map={"Crítico": "#C62828", "Vigilar": "#F9A825"}, template="plotly_white",
    )
    return fig

def inventory_treemap(inventario_marca):
    fig = px.treemap(
        inventario_marca,
        path=["marca"],
        values="valor_inventario",
        color="existencias",
        color_continuous_scale="Blues",
        hover_data={"skus": True, "existencias": ":,.0f", "valor_inventario": ":,.2f"},
        title="Composición del valor de inventario por marca (corte 15-oct-2026)",
    )
    fig.update_traces(textinfo="label+percent parent")
    return fig
    

def coverage_histogram(riesgo, cap=180):
    data = riesgo[riesgo["match_inventario"] & riesgo["cobertura_dias"].notna()].copy()
    data["cobertura_vista"] = data["cobertura_dias"].clip(upper=cap)
    data["nivel_riesgo"] = data["nivel_riesgo"].cat.remove_unused_categories()
    
    fig, ax = plt.subplots(figsize=(10, 4.5))
    sns.histplot(data=data, x="cobertura_vista", hue="nivel_riesgo", bins=35, multiple="stack",
                 palette={"Crítico":"#C62828", "Vigilar":"#F9A825", "Saludable":"#2E7D32"}, ax=ax)
    ax.axvline(15, color="#C62828", linestyle="--", label="Crítico: 15 días")
    ax.axvline(30, color="#F9A825", linestyle="--", label="Vigilar: 30 días")
    ax.set(title="Distribución de cobertura estimada", xlabel=f"Cobertura (días; visualización limitada a {cap})", ylabel="SKUs")
    ax.legend()
    fig.tight_layout()
    return fig

def coverage_boxplot(riesgo, top_n=8, cap=180):
    top = riesgo.groupby("marca")["venta_neta"].sum().nlargest(top_n).index
    data = riesgo[(riesgo["marca"].isin(top)) & riesgo["match_inventario"] & riesgo["cobertura_dias"].notna()].copy()
    data["cobertura_vista"] = data["cobertura_dias"].clip(upper=cap)
    fig, ax = plt.subplots(figsize=(11, 5))
    sns.boxplot(data=data, x="marca", y="cobertura_vista", ax=ax)
    ax.axhline(15, color="#C62828", linestyle="--", label="15 días")
    ax.axhline(30, color="#F9A825", linestyle="--", label="30 días")
    ax.tick_params(axis="x", rotation=35)
    ax.set(title="Cobertura por marca (marcas con mayor venta)", xlabel="Marca", ylabel="Cobertura estimada (días)")
    ax.legend()
    fig.tight_layout()
    return fig
