import pandas as pd
import numpy as np
import streamlit as st

@st.cache_data(show_spinner="Cargando ventas, existencias y salidas...")
def load_sources(path_ventas, path_complementarios):
    ventas = pd.read_excel(path_ventas, sheet_name="Ventas_CLV_2022_2026")
    inventario = pd.read_excel(path_complementarios, sheet_name="Existencias_15_10_2026")
    salidas = pd.read_excel(path_complementarios, sheet_name="Histórico_Entradas_SAlidas")

    ventas["fecha_documento"] = pd.to_datetime(
        ventas["fecha_documento"], format="%d.%m.%Y", errors="coerce"
    )
    ventas["marca"] = ventas["marca"].astype("string").str.strip().str.upper()
    ventas["articulo_key"] = normalizar_llave(ventas["articulo_id"])
    ventas["periodo"] = ventas["fecha_documento"].dt.to_period("M").dt.to_timestamp()

    inventario["marca"] = inventario["marca"].astype("string").str.strip().str.upper()
    inventario["articulo_key"] = normalizar_llave(inventario["articulo"])
    inventario["existencias"] = pd.to_numeric(inventario["existencias"], errors="coerce")
    inventario["valor_inventario"] = pd.to_numeric(inventario["valor_inventario"], errors="coerce")

    salidas["sku_key"] = normalizar_llave(salidas["SKU"])
    salidas["MARCA"] = salidas["MARCA"].astype("string").str.strip().str.upper()
    salidas["SALIDAS"] = pd.to_numeric(salidas["SALIDAS"], errors="coerce")
    salidas["periodo"] = pd.to_datetime(
        dict(year=salidas["ANO"], month=salidas["MES"], day=1), errors="coerce"
    )
    return ventas, inventario, salidas

def normalizar_llave(serie):
    return (
        serie.astype("string")
        .str.strip()
        .str.upper()
        .str.replace(r"\.0$", "", regex=True)
        .replace({"": pd.NA, "NAN": pd.NA, "NONE": pd.NA, "<NA>": pd.NA})
    )

def available_filters(ventas):
    fecha_min = ventas["fecha_documento"].min().date()
    fecha_max = ventas["fecha_documento"].max().date()
    marcas = sorted(ventas["marca"].dropna().unique().tolist())
    return fecha_min, fecha_max, marcas

def filtered_sales(ventas):
    rango = st.session_state.get("filtro_fechas")
    marcas = st.session_state.get("filtro_marcas", [])
    if not rango or len(rango) != 2:
        return ventas.iloc[0:0].copy()
    inicio, fin = pd.to_datetime(rango[0]), pd.to_datetime(rango[1])
    df = ventas.loc[ventas["fecha_documento"].between(inicio, fin)].copy()
    if marcas:
        df = df[df["marca"].isin(marcas)]
    return df

def build_risk_table(ventas_filtradas, inventario):
    """Une ventas e inventario por articulo_id/articulo después de agregar ambas fuentes."""
    if ventas_filtradas.empty:
        return pd.DataFrame()

    dias = max(
        (ventas_filtradas["fecha_documento"].max() - ventas_filtradas["fecha_documento"].min()).days + 1,
        1,
    )
    demanda = (
        ventas_filtradas.groupby("articulo_key", as_index=False)
        .agg(
            nombre_articulo=("nombre_articulo", "first"),
            marca=("marca", "first"),
            unidades_vendidas=("total_unidades", "sum"),
            venta_neta=("total_neto", "sum"),
            folios=("folio", "nunique"),
            clientes=("nombre_cliente", "nunique"),
        )
    )
    demanda["demanda_diaria"] = demanda["unidades_vendidas"] / dias

    stock = (
        inventario.groupby("articulo_key", as_index=False)
        .agg(
            existencias=("existencias", "sum"),
            valor_inventario=("valor_inventario", "sum"),
            almacenes=("almacen", "nunique"),
        )
    )

    riesgo = demanda.merge(
        stock, on="articulo_key", how="left", indicator="estado_union", validate="one_to_one"
    )
    riesgo["match_inventario"] = riesgo["estado_union"].eq("both")
    riesgo[["existencias", "valor_inventario", "almacenes"]] = riesgo[
        ["existencias", "valor_inventario", "almacenes"]
    ].fillna(0)
    riesgo["cobertura_dias"] = np.where(
        riesgo["demanda_diaria"] > 0,
        riesgo["existencias"] / riesgo["demanda_diaria"],
        np.nan,
    )

    def nivel(fila):
        if not fila["match_inventario"]:
            return "Revisar catálogo"
        if fila["cobertura_dias"] < 15:
            return "Crítico"
        if fila["cobertura_dias"] < 30:
            return "Vigilar"
        return "Saludable"

    riesgo["nivel_riesgo"] = riesgo.apply(nivel, axis=1)
    riesgo["nivel_riesgo"] = pd.Categorical(
        riesgo["nivel_riesgo"],
        categories=["Crítico", "Vigilar", "Saludable", "Revisar catálogo"],
        ordered=True,
    )
    return riesgo

def inventory_by_brand(inventario):
    return (
        inventario.groupby("marca", as_index=False)
        .agg(
            skus=("articulo_key", "nunique"),
            existencias=("existencias", "sum"),
            valor_inventario=("valor_inventario", "sum"),
        )
        .sort_values("valor_inventario", ascending=False)
    )
