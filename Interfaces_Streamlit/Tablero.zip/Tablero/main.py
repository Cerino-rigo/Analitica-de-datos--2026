import streamlit as st
from pathlib import Path
from utils.data import load_sources, available_filters
from utils.styles import apply_styles

st.set_page_config(
    page_title="Control de Abastecimiento",
    page_icon="📦",
    layout="wide",
    initial_sidebar_state="expanded",
)

apply_styles()

# Las rutas se centralizan aquí. 
PATH_VENTAS = Path(__file__).resolve().parents[0] / "data" / "Datos_CLV_2026_Tec_v2.xlsx"
PATH_COMPLEMENTARIOS = Path(__file__).resolve().parents[0] / "data" / "Datos_Complementarios_CLV.xlsx"

try:
    ventas, inventario, salidas = load_sources(PATH_VENTAS, PATH_COMPLEMENTARIOS)
except FileNotFoundError as error:
    st.error(f"No se encontró una fuente de datos: {error}")
    st.stop()
except Exception as error:
    st.error(f"No fue posible cargar los datos: {error}")
    st.stop()

# Filtros compartidos: cada página recupera estos valores desde st.session_state.
fecha_min, fecha_max, marcas = available_filters(ventas)
with st.sidebar:
    st.markdown("## Filtros del tablero")
    st.caption("Estos controles afectan las páginas que usan ventas.")

    rango = st.date_input(
        "Periodo de ventas",
        value=(fecha_min, fecha_max),
        min_value=fecha_min,
        max_value=fecha_max,
        key="filtro_fechas",
    )
    marcas_default = marcas
    marcas_elegidas = st.multiselect(
        "Marcas",
        options=marcas,
        key="filtro_marcas",
    )

    st.markdown("---")
    st.caption("Corte de existencias: 15-oct-2026")
    st.info("Los umbrales son didácticos. Una compra real requiere lead time, pedidos abiertos y stock de seguridad.")

# Navegación explícita con st.Page / st.navigation.

pagina_resumen = st.Page("pages/1_resumen_ejecutivo.py", title="Resumen ejecutivo", icon="📊", default=True)
pagina_clusters = st.Page("pages/2_aprendizaje_no_supervisado.py", title="Aprendizaje no supervisado", icon="🧩")
pagina_estadistica = st.Page("pages/3_analisis_estadistico.py", title="Análisis estadístico", icon="📈")

nav = st.navigation(
    {
        "CONTROL DE ABASTECIMIENTO": [pagina_resumen],
        "ANALÍTICA": [pagina_clusters, pagina_estadistica],
    }
)
nav.run()
