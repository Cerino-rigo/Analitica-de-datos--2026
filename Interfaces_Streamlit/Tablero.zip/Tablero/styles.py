import streamlit as st

def apply_styles():
    st.markdown(
        """
        <style>
        .block-container {padding-top: 1.4rem; padding-bottom: 2rem;}
        [data-testid="stMetric"] {
            background: #FFFFFF;
            border: 1px solid #E5E7EB;
            border-radius: 12px;
            padding: 14px;
        }
        .hero {
            padding: 1.25rem 1.5rem;
            border-radius: 14px;
            background: linear-gradient(100deg, #0F3D56, #176B87);
            color: white;
            margin-bottom: 1.1rem;
        }
        .hero h1 {margin: 0; font-size: 2rem;}
        .hero p {margin: .35rem 0 0; color: #DFF6FF;}
        .note {
            border-left: 4px solid #F59E0B;
            background: #FFFBEB;
            padding: .75rem 1rem;
            border-radius: 0 8px 8px 0;
            margin: .75rem 0;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def page_header(title, subtitle):
    st.markdown(
        f"<div class='hero'><h1>{title}</h1><p>{subtitle}</p></div>",
        unsafe_allow_html=True,
    )
